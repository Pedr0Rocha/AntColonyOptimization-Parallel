#ifndef LEITOR_H
#define LEITOR_H

#include <stdio.h>

void leEntrada(char *caminho, int matriz[4][4]);

#endif