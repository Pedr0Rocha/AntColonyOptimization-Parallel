#ifndef HEURISTICA_H
#define HEURISTICA_H

#include <stdio.h>

int calculaHeuristica(int matrizResposta[4][4], int matrizComparar[4][4], int heuristica);

#endif